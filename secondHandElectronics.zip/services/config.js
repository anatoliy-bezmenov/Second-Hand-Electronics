module.exports = {
    SECRET: 'adsj891adshjl1adsjn981adsjko18adskln190adsklasd',
};